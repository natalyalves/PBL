package com.example.pbl;

import android.content.Intent;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

    private static final String REQUEST_TAG = "Login";
    private Button btnLogin;
    private RequestQueue mQueue;
    private EditText edtTxtEmail;
    private EditText edtTxtSenha;
    private TextView cadastrar;
    private TextView mensagem;
    private Usuario usuario = new Usuario();
    private Intent iti;
    private Bundle paramss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cadastrar = (TextView) findViewById(R.id.cadastrarLink);
        btnLogin = (Button) findViewById(R.id.entrarBtn);
        edtTxtEmail = (EditText) findViewById(R.id.emailTxEdt);
        edtTxtSenha = (EditText) findViewById(R.id.senhaTxEdt);
        cadastrar.setAutoLinkMask(Linkify.ALL);
        mensagem = (TextView) findViewById(R.id.mensagemErroTxtView);

        paramss = getIntent().getExtras();
        if (paramss != null){
            if (paramss.getString("cadastrou").equals("sim") ) {
                edtTxtEmail.setText(paramss.getString("login"));
                mensagem.setText("Cadastrado com sucesso!");
            }
        }

}

    @Override
    protected void onStart() {
        super.onStart();
        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtTxtEmail.length() != 0 && edtTxtSenha.length() != 0) {
                    String url = "http://192.168.100.4:8080/PBL/LoginServlet?login=" + edtTxtEmail.getText().toString() + "&senha=" + edtTxtSenha.getText().toString();
                    final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MainActivity.this, MainActivity.this);
                    jsonRequest.setTag(REQUEST_TAG);
                    mQueue.add(jsonRequest);
                }else {
                    mensagem.setText("*Preencha todos os campos.");
                }
            }
        });
        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, CadastroNovoUsuario.class);
                startActivity(it);
            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll(REQUEST_TAG);
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        mensagem.setText("Erro! Verifique sua conexão com a internet");
    }

    @Override
    public void onResponse(JSONObject response) {
        try {

            if ("Login Correto".equals(response.getString("mensagem"))) {
                Intent it = new Intent(MainActivity.this, Menu.class);
                Bundle params = new Bundle();
                usuario.setId(Integer.parseInt(response.getString("id")));
                usuario.setLogin(response.getString("login"));
                usuario.setSenha(response.getString("senha"));
                usuario.setNome(response.getString("nome"));
                usuario.setSobrenome(response.getString("sobrenome"));
                usuario.setTelefone(response.getString("telefone"));
                usuario.setCpf(response.getString("cpf"));
                usuario.setRg(response.getString("rg"));
                usuario.setSexo(response.getString("sexo"));

                Gson gson = new Gson();
                params.putString("usuarioJSON", gson.toJson(usuario));
                it.putExtras(params);
                startActivity(it);
                finish();
            } else if ("Login Incorreto".equals(response.getString("mensagem"))) {
                mensagem.setText("Login ou senha incorretos!");
            }

        } catch (JSONException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
