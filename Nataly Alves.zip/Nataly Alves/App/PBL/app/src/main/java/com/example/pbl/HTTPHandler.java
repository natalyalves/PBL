package com.example.pbl;

import android.graphics.drawable.Drawable;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;


public class HTTPHandler {

    public String makeServiceCall(String reqURL){
        String response = null;

        try {
            URL url = new URL(reqURL);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            InputStream in = new BufferedInputStream(con.getInputStream());
            response = convertStreamToString(in);
        }catch (Exception e){
            e.printStackTrace();
        }
        return response;
    }

    private String convertStreamToString(InputStream is){
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null){
                sb.append(line).append("\n");
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public Drawable makeServiceCallImage(String reqURL){

        try {
            InputStream is = (InputStream) new URL(reqURL).getContent();
            Drawable d = Drawable.createFromStream(is, "carro");
            return d;
        } catch (Exception e) {
            System.out.println("Exc=" + e);
            return null;
        }
    }
}
