            package com.example.pbl;

            import android.app.AlertDialog;
            import android.content.DialogInterface;
            import android.content.Intent;
            import android.os.Bundle;
            import android.view.View;
            import android.widget.Button;
            import android.widget.EditText;
            import android.widget.RadioButton;
            import android.widget.RadioGroup;
            import android.widget.TextView;
            import android.widget.Toast;

            import androidx.appcompat.app.AppCompatActivity;

            import com.android.volley.Request;
            import com.android.volley.RequestQueue;
            import com.android.volley.Response;
            import com.android.volley.VolleyError;
            import com.google.gson.Gson;

            import org.json.JSONException;
            import org.json.JSONObject;

            public class MeusAnimais extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

                private static final String REQUEST_TAG = "Alterar";
                Usuario usuario;
                private Animal animal = new Animal();
                private Intent it;
                private Bundle params;
                private TextView totalMeuAnimalTxtView;
                private TextView mensagemErroMeuAnimalTxtView;
                private EditText nomeMeuAnimalTxtEdt;
                private EditText tipoMeuAnimalTxtEdt;
                private EditText racaMeuAnimalTxtEdt;
                private EditText porteMeuAnimalTxtEdt;
                private RadioGroup sexoMeuAnimalRadioGroup;
                private RadioButton femeaMeuAnimalCheck;
                private RadioButton machoMeuAnimalCheck;
                private TextView statusMensagemMeuAnimalTxtView;
                private Button alterarMeuAnimalBtn;
                private Button excluirMeuAnimalBtn;
                private Button esquerdaBtn;
                private Button direitaBtn;
                private RequestQueue mQueue;
                int idAnimalAtual = 1;
                int quantidade = 0;
                private boolean excluiu = false;
                private boolean buscando = true;
                private boolean alterando = false;
                private String sim;
                private String nao;

                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    setContentView(R.layout.meus_animais);

                    totalMeuAnimalTxtView = (TextView) findViewById(R.id.totalMeuAnimalTxtView);
                    mensagemErroMeuAnimalTxtView = (TextView) findViewById(R.id.mensagemErroMeuAnimalTxtView);
                    nomeMeuAnimalTxtEdt = (EditText) findViewById(R.id.nomeMeuAnimalTxtEdt);
                    tipoMeuAnimalTxtEdt = (EditText) findViewById(R.id.tipoMeuAnimalTxtEdt);
                    racaMeuAnimalTxtEdt = (EditText) findViewById(R.id.racaMeuAnimalTxtEdt);
                    porteMeuAnimalTxtEdt = (EditText) findViewById(R.id.porteMeuAnimalTxtEdt);
                    sexoMeuAnimalRadioGroup = (RadioGroup) findViewById(R.id.sexoMeuAnimalRadioGroup);
                    femeaMeuAnimalCheck = (RadioButton) findViewById(R.id.femeaMeuAnimalCheck);
                    machoMeuAnimalCheck = (RadioButton) findViewById(R.id.machoMeuAnimalCheck);
                    statusMensagemMeuAnimalTxtView = (TextView) findViewById(R.id.statusMensagemMeuAnimalTxtView);
                    alterarMeuAnimalBtn = (Button) findViewById(R.id.alterarMeuAnimalBtn);
                    excluirMeuAnimalBtn = (Button) findViewById(R.id.excluirMeuAnimalBtn);
                    esquerdaBtn = (Button) findViewById(R.id.esquerdaBtn);
                    direitaBtn = (Button) findViewById(R.id.direitaBtn);
                    esquerdaBtn.setEnabled(false);


                    it = getIntent();
                    params = it.getExtras();
                    Gson gson = new Gson();
                    usuario = gson.fromJson(params.getString("usuarioJSON"), Usuario.class);

                }

                @Override
                protected void onStart() {
                    super.onStart();
                    mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
                    String url = "http://192.168.100.4:8080/PBL/BuscarAnimalServlet?id=1" + "&dono=" + usuario.getId();
                    final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeusAnimais.this, MeusAnimais.this);
                    jsonRequest.setTag("buscarAnimal");
                    mQueue.add(jsonRequest);

                    alterarMeuAnimalBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            alterando = true;
                            excluiu = false;
                            buscando = false;
                            int sexoSelecionadoId = sexoMeuAnimalRadioGroup.getCheckedRadioButtonId();
                            RadioButton selectedRadioButton = (RadioButton) findViewById(sexoSelecionadoId);
                            String sexoSelecionado = selectedRadioButton.getText().toString();
                            String url = "http://192.168.100.4:8080/PBL/AlterarAnimalServlet?id=" + animal.getId() + "&nome=" + nomeMeuAnimalTxtEdt.getText().toString() + "&raca=" + racaMeuAnimalTxtEdt.getText().toString() + "&porte=" + porteMeuAnimalTxtEdt.getText().toString() + "&sexo=" + sexoSelecionado;
                                    final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeusAnimais.this, MeusAnimais.this);
                                    jsonRequest.setTag(REQUEST_TAG);
                                    mQueue.add(jsonRequest);
                        }
                    });

                    excluirMeuAnimalBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            new AlertDialog.Builder(MeusAnimais.this)
                                    .setTitle("Excluir")
                                    .setMessage("Deseja realmente excluir esse animal?")
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            String url = "http://192.168.100.4:8080/PBL/ExcluirAnimalServlet?id=" + animal.getId();
                                            final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeusAnimais.this, MeusAnimais.this);
                                            jsonRequest.setTag(REQUEST_TAG);
                                            mQueue.add(jsonRequest);
                                            alterando = false;
                                            excluiu = true;
                                            buscando = false;
                                            dialog.dismiss();
                                        }
                                    })
                                    .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            // User cancelled the dialog
                                        }
                                    })
                                    .show();


                        }
                    });

                    esquerdaBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            idAnimalAtual =  idAnimalAtual - 1;
                            direitaBtn.setEnabled(true);
                            if(idAnimalAtual == 1)
                                esquerdaBtn.setEnabled(false);
                            String url = "http://192.168.100.4:8080/PBL/BuscarAnimalServlet?id=" + idAnimalAtual + "&dono=" + usuario.getId();
                            final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeusAnimais.this, MeusAnimais.this);
                            jsonRequest.setTag("buscarAnimal");
                            mQueue.add(jsonRequest);
                            alterando = false;
                            excluiu = false;
                            buscando = true;
                            mensagemErroMeuAnimalTxtView.setText("");
                        }
                    });

                    direitaBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            idAnimalAtual =  idAnimalAtual + 1;
                            esquerdaBtn.setEnabled(true);
                            if(quantidade == idAnimalAtual)
                                direitaBtn.setEnabled(false);
                            String url = "http://192.168.100.4:8080/PBL/BuscarAnimalServlet?id=" + idAnimalAtual + "&dono=" + usuario.getId();
                            final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeusAnimais.this, MeusAnimais.this);
                            jsonRequest.setTag("buscarAnimal");
                            mQueue.add(jsonRequest);
                            alterando = false;
                            excluiu = false;
                            buscando = true;
                            mensagemErroMeuAnimalTxtView.setText("");
                        }
                    });

                }

                @Override
                protected void onStop() {
                    super.onStop();
                    if (mQueue != null) {
                        mQueue.cancelAll(REQUEST_TAG);
                    }
                }

                @Override
                public void onErrorResponse(VolleyError error) {
                    mensagemErroMeuAnimalTxtView.setText("Erro! Verifique sua conexão com a internet");
                }

                @Override
                public void onResponse(JSONObject response) {

                    if(buscando)

                        try {
                            if(response.getString("mensagem").equals("Nenhum animal cadastrado!")){
                                mensagemErroMeuAnimalTxtView.setText("Nenhum animal cadastrado!");
                                tipoMeuAnimalTxtEdt.setEnabled(false);

                                nomeMeuAnimalTxtEdt.setEnabled(false);
                                racaMeuAnimalTxtEdt.setEnabled(false);
                                porteMeuAnimalTxtEdt.setEnabled(false);
                                sexoMeuAnimalRadioGroup.setEnabled(false);
                                alterarMeuAnimalBtn.setEnabled(false);
                                excluirMeuAnimalBtn.setEnabled(false);
                                esquerdaBtn.setEnabled(false);
                                direitaBtn.setEnabled(false);
                            }
                            else {
                                animal.setId(Integer.parseInt(response.getString("id")));
                                quantidade = Integer.parseInt(response.getString("quantidade"));
                                totalMeuAnimalTxtView.setText(idAnimalAtual + " de " + quantidade);
                                nomeMeuAnimalTxtEdt.setText(response.getString("nome"));
                                tipoMeuAnimalTxtEdt.setText(response.getString("tipo"));
                                racaMeuAnimalTxtEdt.setText(response.getString("raca"));
                                porteMeuAnimalTxtEdt.setText(response.getString("porte"));
                                if (response.getString("sexo").equals("Macho")) {
                                    femeaMeuAnimalCheck.setChecked(false);
                                    machoMeuAnimalCheck.setChecked(true);
                                } else if (response.getString("sexo").equals("Fêmea")) {
                                    machoMeuAnimalCheck.setChecked(false);
                                    femeaMeuAnimalCheck.setChecked(true);
                                } else {
                                    machoMeuAnimalCheck.setChecked(false);
                                    femeaMeuAnimalCheck.setChecked(false);
                                }

                                statusMensagemMeuAnimalTxtView.setText(response.getString("situacao"));


                                tipoMeuAnimalTxtEdt.setEnabled(false);

                                nomeMeuAnimalTxtEdt.setEnabled(true);
                                racaMeuAnimalTxtEdt.setEnabled(true);
                                porteMeuAnimalTxtEdt.setEnabled(true);
                                sexoMeuAnimalRadioGroup.setEnabled(true);
                                alterarMeuAnimalBtn.setEnabled(true);
                                excluirMeuAnimalBtn.setEnabled(true);

                                if (quantidade == 1) {
                                    esquerdaBtn.setEnabled(false);
                                    direitaBtn.setEnabled(false);
                                }
                            }
                            } catch (JSONException e) {
                            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    else if(alterando){
                        try {
                        mensagemErroMeuAnimalTxtView.setText(response.getString("mensagem"));
                        } catch (JSONException e) {
                            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                    else if (excluiu){

                        try {
                            if(response.getString("mensagem").equals("Animal excluído com sucesso!")) {
                                totalMeuAnimalTxtView.setText(idAnimalAtual + " de " + (quantidade -1));
                                nomeMeuAnimalTxtEdt.setText("");
                                tipoMeuAnimalTxtEdt.setText("");
                                racaMeuAnimalTxtEdt.setText("");
                                porteMeuAnimalTxtEdt.setText("");

                                machoMeuAnimalCheck.setChecked(false);
                                femeaMeuAnimalCheck.setChecked(false);

                                statusMensagemMeuAnimalTxtView.setText("");

                                tipoMeuAnimalTxtEdt.setEnabled(false);
                                nomeMeuAnimalTxtEdt.setEnabled(false);
                                racaMeuAnimalTxtEdt.setEnabled(false);
                                porteMeuAnimalTxtEdt.setEnabled(false);
                                sexoMeuAnimalRadioGroup.setEnabled(false);
                                alterarMeuAnimalBtn.setEnabled(false);
                                excluirMeuAnimalBtn.setEnabled(false);

                                mensagemErroMeuAnimalTxtView.setText(response.getString("mensagem"));
                            }
                            else{
                                mensagemErroMeuAnimalTxtView.setText(response.getString("mensagem"));
                            }
                        } catch (JSONException e) {
                            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }




                    }

                }

            }
