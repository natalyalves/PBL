package com.example.pbl;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class AnimaisAdotarPorTipo extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

    private static final String REQUEST_TAG = "AnimaisPorTipo";
    Usuario usuario;
    private Animal animal = new Animal();
    private Intent it;
    private Bundle params;
    private TextView totalPorTipoTxtView;
    private TextView tituloPorTipoTxtView;
    private TextView mensagemErroPorTipoTxtView;
    private EditText nomePorTipoTxtEdt;
    private EditText tipoPorTipoTxtEdt;
    private EditText racaPorTipoTxtEdt;
    private EditText portePorTipoTxtEdt;
    private RadioGroup sexoPorTipoRadioGroup;
    private RadioButton femeaPorTipoCheck;
    private RadioButton machoPorTipoCheck;
    private TextView donoMensagemPorTipoTxtView;
    private Button adotarPorTipoBtn;
    private Button esquerdaPorTipoBtn;
    private Button direitaPorTipoBtn;
    private RequestQueue mQueue;
    int idAnimalAtual = 1;
    int quantidade = 0;
    private boolean excluiu = false;
    private boolean buscando = true;
    private boolean alterando = false;
    private String tipo;
    private String telefoneDono;
    private String nomeDono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adocao_por_tipo);

        totalPorTipoTxtView = (TextView) findViewById(R.id.totalPorTipoTxtView);
        tituloPorTipoTxtView = (TextView) findViewById(R.id.tituloPorTipoTxtView);
        mensagemErroPorTipoTxtView = (TextView) findViewById(R.id.mensagemErroPorTipoTxtView);
        nomePorTipoTxtEdt = (EditText) findViewById(R.id.nomePorTipoTxtEdt);
        tipoPorTipoTxtEdt = (EditText) findViewById(R.id.tipoPorTipoTxtEdt);
        racaPorTipoTxtEdt = (EditText) findViewById(R.id.racaPorTipoTxtEdt);
        portePorTipoTxtEdt = (EditText) findViewById(R.id.portePorTipoTxtEdt);
        sexoPorTipoRadioGroup = (RadioGroup) findViewById(R.id.sexoPorTipoRadioGroup);
        femeaPorTipoCheck = (RadioButton) findViewById(R.id.femeaPorTipoCheck);
        machoPorTipoCheck = (RadioButton) findViewById(R.id.machoPorTipoCheck);
        donoMensagemPorTipoTxtView = (TextView) findViewById(R.id.donoMensagemPorTipoTxtView);
        adotarPorTipoBtn = (Button) findViewById(R.id.adotarPorTipoBtn);
        esquerdaPorTipoBtn = (Button) findViewById(R.id.esquerdaPorTipoBtn);
        direitaPorTipoBtn = (Button) findViewById(R.id.direitaPorTipoBtn);
        esquerdaPorTipoBtn.setEnabled(false);

        it = getIntent();
        params = it.getExtras();
        Gson gson = new Gson();
        usuario = gson.fromJson(params.getString("usuarioJSON"), Usuario.class);
        tipo = params.getString("tipo");

        tituloPorTipoTxtView.setText(tipo);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
        String url = "http://192.168.100.4:8080/PBL/BuscarAnimaisPorTipoServlet?id=1" + "&tipo=" + tipo;
        final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), AnimaisAdotarPorTipo.this, AnimaisAdotarPorTipo.this);
        jsonRequest.setTag("buscarPorTipo");
        mQueue.add(jsonRequest);

        adotarPorTipoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(AnimaisAdotarPorTipo.this)
                        .setTitle("Confirmar adoção")
                        .setMessage("Deseja realmente adotar esse animal?\n**Lembre-se que, ao clicar em \"Sim\" você tem a responsabilidade de entrar em contato com o dono do animal!")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                String url = "http://192.168.100.4:8080/PBL/AdotarAnimalServlet?id=" + animal.getId();
                                final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), AnimaisAdotarPorTipo.this, AnimaisAdotarPorTipo.this);
                                jsonRequest.setTag(REQUEST_TAG);
                                mQueue.add(jsonRequest);
                                alterando = true;
                                excluiu = false;
                                buscando = false;

                                new AlertDialog.Builder(AnimaisAdotarPorTipo.this)
                                        .setTitle("Adotado Com sucesso!")
                                        .setMessage("Por favor, entre em contato com o dono para que possam combinar a entrega do animal!\n\n Nome:" + nomeDono + "\n Telefone:" + telefoneDono)
                                        .setIcon(android.R.drawable.ic_dialog_alert)
                                        .show();
                                dialog.dismiss();
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // User cancelled the dialog
                            }
                        })
                        .show();
            }
        });

        esquerdaPorTipoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                idAnimalAtual =  idAnimalAtual - 1;
                direitaPorTipoBtn.setEnabled(true);
                if(idAnimalAtual == 1)
                    esquerdaPorTipoBtn.setEnabled(false);
                String url = "http://192.168.100.4:8080/PBL/BuscarAnimaisPorTipoServlet?id=" + idAnimalAtual + "&tipo=" + tipo;
                final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), AnimaisAdotarPorTipo.this, AnimaisAdotarPorTipo.this);
                jsonRequest.setTag("buscarAnimalTipo");
                mQueue.add(jsonRequest);
                alterando = false;
                excluiu = false;
                buscando = true;
                mensagemErroPorTipoTxtView.setText("");
            }
        });

        direitaPorTipoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                idAnimalAtual =  idAnimalAtual + 1;
                esquerdaPorTipoBtn.setEnabled(true);
                if(quantidade == idAnimalAtual)
                    direitaPorTipoBtn.setEnabled(false);
                String url = "http://192.168.100.4:8080/PBL/BuscarAnimaisPorTipoServlet?id=" + idAnimalAtual + "&tipo=" + tipo;
                final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), AnimaisAdotarPorTipo.this, AnimaisAdotarPorTipo.this);
                jsonRequest.setTag("buscarAnimalTipo");
                mQueue.add(jsonRequest);
                alterando = false;
                excluiu = false;
                buscando = true;
                mensagemErroPorTipoTxtView.setText("");
            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll(REQUEST_TAG);
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        mensagemErroPorTipoTxtView.setText("Erro! Verifique sua conexão com a internet");
    }

    @Override
    public void onResponse(JSONObject response) {

        if(buscando)
        try {
            if(response.getString("mensagem").equals("Nenhum animal cadastrado!")){
                mensagemErroPorTipoTxtView.setText("Nenhum animal cadastrado!");
                esquerdaPorTipoBtn.setEnabled(false);
                direitaPorTipoBtn.setEnabled(false);
                tipoPorTipoTxtEdt.setEnabled(false);
                nomePorTipoTxtEdt.setEnabled(false);
                racaPorTipoTxtEdt.setEnabled(false);
                portePorTipoTxtEdt.setEnabled(false);
                machoPorTipoCheck.setEnabled(false);
                femeaPorTipoCheck.setEnabled(false);
                adotarPorTipoBtn.setEnabled(false);
            }
            else{
                animal.setId(Integer.parseInt(response.getString("id")));
                quantidade = Integer.parseInt(response.getString("quantidade"));
                totalPorTipoTxtView.setText(idAnimalAtual + " de " + quantidade);
                nomePorTipoTxtEdt.setText(response.getString("nome"));
                tipoPorTipoTxtEdt.setText(response.getString("tipo"));
                racaPorTipoTxtEdt.setText(response.getString("raca"));
                portePorTipoTxtEdt.setText(response.getString("porte"));
                telefoneDono = response.getString("telefoneDono");
                nomeDono = response.getString("dono");

                if (response.getString("sexo").equals("Macho")) {
                    femeaPorTipoCheck.setChecked(false);
                    machoPorTipoCheck.setChecked(true);
                } else if (response.getString("sexo").equals("Fêmea")) {
                    machoPorTipoCheck.setChecked(false);
                    femeaPorTipoCheck.setChecked(true);
                } else {
                    machoPorTipoCheck.setChecked(false);
                    femeaPorTipoCheck.setChecked(false);
                }

                donoMensagemPorTipoTxtView.setText(response.getString("dono"));

                tipoPorTipoTxtEdt.setEnabled(false);
                nomePorTipoTxtEdt.setEnabled(false);
                racaPorTipoTxtEdt.setEnabled(false);
                portePorTipoTxtEdt.setEnabled(false);
                machoPorTipoCheck.setEnabled(false);
                femeaPorTipoCheck.setEnabled(false);
                adotarPorTipoBtn.setEnabled(true);

                if (quantidade == 1) {
                    esquerdaPorTipoBtn.setEnabled(false);
                    direitaPorTipoBtn.setEnabled(false);
                }
            }
        } catch (JSONException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        else if(alterando){
            try {
                mensagemErroPorTipoTxtView.setText(response.getString("mensagem"));
                adotarPorTipoBtn.setEnabled(false);
            } catch (JSONException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
