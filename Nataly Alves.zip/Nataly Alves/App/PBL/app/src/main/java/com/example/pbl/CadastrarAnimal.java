package com.example.pbl;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class CadastrarAnimal extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject>, AdapterView.OnItemSelectedListener {

    private static final String REQUEST_TAG = "CadastroAnimal";
    private Intent it;
    private Bundle params;
    private EditText nomeNovoAnimalEdtTxt;
    private Spinner tipoNovoAnimalSpinner;
    private EditText racaNovoAnimalEdtTxt;
    private EditText porteNovoAnimalEdtTxt;
    private RadioGroup sexoNovoAnimalRadioGroup;
    private TextView txtMsg;
    private Button cadastrarNovoAnimalBtn;
    private RequestQueue mQueue;
    private RadioButton femeaCheck;
    private RadioButton machoCheck;
    private String tipoEscolhido;
    private Usuario usuario = new Usuario();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro_animal);

        txtMsg = (TextView) findViewById(R.id.mensagemErroTeste);
        nomeNovoAnimalEdtTxt = (EditText) findViewById(R.id.nomeNovoAnimalEdtTxt);

        tipoNovoAnimalSpinner = (Spinner) findViewById(R.id.tipoNovoAnimalSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.tipo_animal, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipoNovoAnimalSpinner.setAdapter(adapter);
        tipoNovoAnimalSpinner.setOnItemSelectedListener(this);

        racaNovoAnimalEdtTxt = (EditText) findViewById(R.id.racaNovoAnimalEdtTxt);
        porteNovoAnimalEdtTxt = (EditText) findViewById(R.id.porteNovoAnimalEdtTxt);
        sexoNovoAnimalRadioGroup = (RadioGroup) findViewById(R.id.sexoNovoAnimalRadioGroup);
        cadastrarNovoAnimalBtn = (Button) findViewById(R.id.cadastrarNovoAnimalBtn);

        it = getIntent();
        params = it.getExtras();
        Gson gson = new Gson();
        usuario = gson.fromJson(params.getString("usuarioJSON"), Usuario.class);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
        cadastrarNovoAnimalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedRadioButtonID = sexoNovoAnimalRadioGroup.getCheckedRadioButtonId();
                String selectedRadioButtonText = "Não Definido";
                if(selectedRadioButtonID != -1) {
                    RadioButton selectedRadioButton = (RadioButton) findViewById(selectedRadioButtonID);
                    selectedRadioButtonText = selectedRadioButton.getText().toString();
                }
                if (porteNovoAnimalEdtTxt.length() != 0) {


                        String url = "http://192.168.100.4:8080/PBL/CadastroAnimalServlet?nome=" + nomeNovoAnimalEdtTxt.getText().toString() + "&tipo=" + tipoEscolhido + "&raca=" + racaNovoAnimalEdtTxt.getText().toString() + "&porte=" + porteNovoAnimalEdtTxt.getText().toString() + "&sexo=" + selectedRadioButtonText + "&dono=" +  usuario.getId();
                        final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), CadastrarAnimal.this, CadastrarAnimal.this);
                        jsonRequest.setTag(REQUEST_TAG);
                        mQueue.add(jsonRequest);
                } else {
                    txtMsg.setText("**Preencha o porte do animal.");
                }
            }
        });
    }

    public void onItemSelected(AdapterView<?> parent, View view,int pos, long id) {

        tipoEscolhido = parent.getItemAtPosition(pos).toString();
    }
    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }
    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll(REQUEST_TAG);
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        txtMsg.setText("Erro! Verifique sua conexão com a internet");
    }

    @Override
    public void onResponse(JSONObject response) {
        try {

            if ("Cadastrado com sucesso".equals(response.getString("mensagem"))) {
                Intent it = new Intent(CadastrarAnimal.this, MeusAnimais.class);
                Gson gson = new Gson();
                params.putString("usuarioJSON", gson.toJson(usuario));
                it.putExtras(params);
                startActivity(it);
                finish();
            } else {
                txtMsg.setText(response.getString("mensagem"));
            }

        } catch (JSONException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
