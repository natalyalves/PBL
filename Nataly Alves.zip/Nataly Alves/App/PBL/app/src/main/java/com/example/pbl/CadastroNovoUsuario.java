package com.example.pbl;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import org.json.JSONException;
import org.json.JSONObject;

public class CadastroNovoUsuario extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

    private static final String REQUEST_TAG = "Cadastro";
    private EditText nomeNovoUsuario;
    private EditText sobrenomeNovoUsuario;
    private EditText emailNovoUsuario;
    private EditText telefoneNovoUsuario;
    private EditText rgNovoUsuario;
    private EditText cpfNovoUsuario;
    private EditText senhaNovoUsuario;
    private EditText confirmacaoSenhaNovoUsuario;
    private RadioGroup sexoRadioGroup;
    private TextView txtMsg;
    private Button cadastroBtn;
    private RequestQueue mQueue;
    private Usuario usuario = new Usuario();
    private RadioButton feminino;
    private RadioButton masculino;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.novo_cadastro);

        txtMsg = (TextView) findViewById(R.id.MensagemErro);
        nomeNovoUsuario = (EditText) findViewById(R.id.nomeCadastroPessoaTxtView);
        sobrenomeNovoUsuario = (EditText) findViewById(R.id.sobrenomeCadastroPessoaEdtTxt);
        emailNovoUsuario = (EditText) findViewById(R.id.emailCadastroPessoaEdtTxt);
        senhaNovoUsuario = (EditText) findViewById(R.id.senhaCadastroPessoaEdtTxt);
        telefoneNovoUsuario = (EditText) findViewById(R.id.telefoneCadastroPessoaEdtTxt);
        rgNovoUsuario = (EditText) findViewById(R.id.rgCadastroPessoaEdtTxt);
        cpfNovoUsuario = (EditText) findViewById(R.id.cpfCadastroPessoaEdtTxt);
        sexoRadioGroup = (RadioGroup) findViewById(R.id.sexoRadioGroup);

        confirmacaoSenhaNovoUsuario = (EditText) findViewById(R.id.confimacaoSenhaCadastroPessoaEdtTxt);
        cadastroBtn = (Button) findViewById(R.id.cadastroBtn);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
        cadastroBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedRadioButtonID = sexoRadioGroup.getCheckedRadioButtonId();
                if (nomeNovoUsuario.length() != 0 && sobrenomeNovoUsuario.length() != 0 && emailNovoUsuario.length() != 0 && senhaNovoUsuario.length() != 0 && rgNovoUsuario.length() != 0 && cpfNovoUsuario.length() != 0 && telefoneNovoUsuario.length() != 0 && confirmacaoSenhaNovoUsuario.length() != 0 && selectedRadioButtonID != -1) {
                    if (senhaNovoUsuario.getText().toString().equals(confirmacaoSenhaNovoUsuario.getText().toString())){
                        RadioButton selectedRadioButton = (RadioButton) findViewById(selectedRadioButtonID);
                        String selectedRadioButtonText = selectedRadioButton.getText().toString();
                        String url = "http://192.168.100.4:8080/PBL/CadastroServlet?login=" + emailNovoUsuario.getText().toString() + "&senha=" + senhaNovoUsuario.getText().toString() + "&nome=" + nomeNovoUsuario.getText().toString() + "&sobrenome=" + sobrenomeNovoUsuario.getText().toString() + "&telefone=" + telefoneNovoUsuario.getText().toString() + "&cpf=" + cpfNovoUsuario.getText().toString() + "&rg=" + rgNovoUsuario.getText().toString() + "&sexo=" + selectedRadioButtonText;
                    final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), CadastroNovoUsuario.this, CadastroNovoUsuario.this);
                    jsonRequest.setTag(REQUEST_TAG);
                    mQueue.add(jsonRequest);
                    }else {
                        txtMsg.setText("*As senhas não coincidem.");
                    }
                } else {
                    txtMsg.setText("*Preencha todos os campos.");
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll(REQUEST_TAG);
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        txtMsg.setText("Erro! Verifique sua conexão com a internet");
    }

    @Override
    public void onResponse(JSONObject response) {
        try {

            if ("Cadastrado com sucesso".equals(response.getString("mensagem"))) {
                Intent it = new Intent(CadastroNovoUsuario.this, MainActivity.class);
                Bundle params = new Bundle();
                params.putString("cadastrou", "sim");
                params.putString("login", emailNovoUsuario.getText().toString() );
                it.putExtras(params);
                startActivity(it);
                finish();
            } else {
                txtMsg.setText(response.getString("mensagem"));
            }

        } catch (JSONException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
