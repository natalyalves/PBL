package com.example.pbl;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class MeuPerfil extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

    private static final String REQUEST_TAG = "Alterar";
    Usuario usuario;
    private Intent it;
    private Bundle params;
    private EditText nomeMeuPerfilEdtTxt;
    private EditText sobrenomeMeuPerfilEdtTxt;
    private EditText emailMeuPerfilEdtTxt;
    private EditText telefoneMeuPerfilEdtTxt;
    private EditText cpfMeuPerfilEdtTxt;
    private EditText rgMeuPerfilEdtTxt;
    private EditText senhaMeuPerfilEdtTxt;
    private EditText confirmacaoSenhaMeuPerfilEdtTxt;
    private EditText sexoMeuPerfilEdtTxt;
    private Button alterarInformacoesBtn;
    private RequestQueue mQueue;
    private TextView mensagemTxtView;
    private boolean comecou = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meu_perfil);

        mensagemTxtView = (TextView) findViewById(R.id.mensagemTxtView);
        nomeMeuPerfilEdtTxt = (EditText) findViewById(R.id.nomeMeuPerfilEdtTxt);
        sobrenomeMeuPerfilEdtTxt = (EditText) findViewById(R.id.sobrenomeMeuPerfilEdtTxt);
        emailMeuPerfilEdtTxt = (EditText) findViewById(R.id.emailMeuPerfilEdtTxt);
        telefoneMeuPerfilEdtTxt = (EditText) findViewById(R.id.telefoneMeuPerfilEdtTxt);
        cpfMeuPerfilEdtTxt = (EditText) findViewById(R.id.cpfMeuPerfilEdtTxt);
        rgMeuPerfilEdtTxt = (EditText) findViewById(R.id.rgMeuPerfilEdtTxt);
        sexoMeuPerfilEdtTxt = (EditText) findViewById(R.id.sexoMeuPerfilEdtTxt);
        senhaMeuPerfilEdtTxt = (EditText) findViewById(R.id.senhaMeuPerfilEdtTxt);
        confirmacaoSenhaMeuPerfilEdtTxt = (EditText) findViewById(R.id.confirmacaoSenhaMeuPerfilEdtTxt);
        alterarInformacoesBtn = (Button) findViewById(R.id.alterarInformacoesBtn);

        it = getIntent();
        params = it.getExtras();
        Gson gson = new Gson();
        usuario = gson.fromJson(params.getString("usuarioJSON"), Usuario.class);

    }

    @Override
    protected void onStart() {
        super.onStart();
        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
        String url = "http://192.168.100.4:8080/PBL/BuscarUsuarioServlet?cpf=" + usuario.getCpf();
        final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeuPerfil.this, MeuPerfil.this);
        jsonRequest.setTag("busca");
        mQueue.add(jsonRequest);

        alterarInformacoesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comecou = false;

                if (nomeMeuPerfilEdtTxt.length() != 0 && senhaMeuPerfilEdtTxt.length() != 0 && telefoneMeuPerfilEdtTxt.length() != 0 && confirmacaoSenhaMeuPerfilEdtTxt.length() != 0) {
                    if (senhaMeuPerfilEdtTxt.getText().toString().equals(confirmacaoSenhaMeuPerfilEdtTxt.getText().toString())){
                        String url = "http://192.168.100.4:8080/PBL/AlterarServlet?senha=" + senhaMeuPerfilEdtTxt.getText().toString() + "&nome=" + nomeMeuPerfilEdtTxt.getText().toString() + "&sobrenome=" + sobrenomeMeuPerfilEdtTxt.getText().toString() + "&telefone=" + telefoneMeuPerfilEdtTxt.getText().toString() + "&cpf=" + cpfMeuPerfilEdtTxt.getText().toString();
                        final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), MeuPerfil.this, MeuPerfil.this);
                        jsonRequest.setTag(REQUEST_TAG);
                        mQueue.add(jsonRequest);
                    }else {
                        mensagemTxtView.setText("*As senhas não coincidem.");
                    }
                } else {
                    mensagemTxtView.setText("*Preencha todos os campos.");
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll(REQUEST_TAG);
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        mensagemTxtView.setText("Erro! Verifique sua conexão com a internet");
    }

    @Override
    public void onResponse(JSONObject response) {
        if(comecou)
        try {
        nomeMeuPerfilEdtTxt.setText(response.getString("nome"));
        sobrenomeMeuPerfilEdtTxt.setText(response.getString("sobrenome"));
        emailMeuPerfilEdtTxt.setText(response.getString("login"));
        telefoneMeuPerfilEdtTxt.setText(response.getString("telefone"));
        cpfMeuPerfilEdtTxt.setText(response.getString("cpf"));
        rgMeuPerfilEdtTxt.setText(response.getString("rg"));
        sexoMeuPerfilEdtTxt.setText(response.getString("sexo"));
        senhaMeuPerfilEdtTxt.setText(response.getString("senha"));

        sexoMeuPerfilEdtTxt.setEnabled(false);
        emailMeuPerfilEdtTxt.setEnabled(false);
        rgMeuPerfilEdtTxt.setEnabled(false);
        cpfMeuPerfilEdtTxt.setEnabled(false);
        } catch (JSONException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        else
        try {
                mensagemTxtView.setText(response.getString("mensagem"));

        } catch (JSONException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}
