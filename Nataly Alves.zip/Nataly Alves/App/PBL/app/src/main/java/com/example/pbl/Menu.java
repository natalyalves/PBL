package com.example.pbl;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;


public class Menu extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

    Usuario usuario;
    private Intent it;
    private Bundle params;
    private TextView nomeUsuario;
    private Button meuPerfilBtn;
    private Button meusAnimaisBtn;
    private Button cadastrarAnimalBtn;
    private Button adotarAnimaisBtn;
    private RequestQueue mQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);

        nomeUsuario = (TextView) findViewById(R.id.bemVindoTxtView);
        meuPerfilBtn = (Button) findViewById(R.id.meuPerfilBtn);
        meusAnimaisBtn = (Button) findViewById(R.id.meusAnimaisBtn);
        cadastrarAnimalBtn = (Button) findViewById(R.id.cadastrarAnimalBtn);
        adotarAnimaisBtn = (Button) findViewById(R.id.adotarAnimaisBtn);

        it = getIntent();
        params = it.getExtras();
        Gson gson = new Gson();
        usuario = gson.fromJson(params.getString("usuarioJSON"), Usuario.class);

        if(usuario.getSexo().equals("Masculino"))
            nomeUsuario.setText("Bem Vindo, " + usuario.getNome() + "!");
        else
            nomeUsuario.setText("Bem Vinda, " + usuario.getNome() + "!");

    }

    @Override
    protected void onStart() {
        super.onStart();


        meuPerfilBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Menu.this, MeuPerfil.class);
                Gson gson = new Gson();
                params.putString("usuarioJSON", gson.toJson(usuario));
                it.putExtras(params);
                startActivity(it);
            }
        });

        meusAnimaisBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Menu.this, MeusAnimais.class);
                Gson gson = new Gson();
                params.putString("usuarioJSON", gson.toJson(usuario));
                it.putExtras(params);
                startActivity(it);
            }
        });

        cadastrarAnimalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Menu.this, CadastrarAnimal.class);
                Gson gson = new Gson();
                params.putString("usuarioJSON", gson.toJson(usuario));
                it.putExtras(params);
                startActivity(it);
            }
        });

        adotarAnimaisBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Menu.this, AnimaisParaAdocao.class);
                Gson gson = new Gson();
                params.putString("usuarioJSON", gson.toJson(usuario));
                it.putExtras(params);
                startActivity(it);
            }
        });
    }

    @Override
    public void onResume(){
        super.onResume();
        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext()).getRequestQueue();
        String url = "http://192.168.100.4:8080/PBL/BuscarUsuarioServlet?cpf=" + usuario.getCpf();
        final CustomJSONObjectRequest jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, url, new JSONObject(), Menu.this, Menu.this);
        jsonRequest.setTag("busca");
        mQueue.add(jsonRequest);

    }


    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll("busca");
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {

    }

    @Override
    public void onResponse(JSONObject response) {

            try {
                if(response.getString("sexo").equals("Masculino"))
                    nomeUsuario.setText("Bem Vindo, " + response.getString("nome") + "!");
                else
                    nomeUsuario.setText("Bem Vinda, " + response.getString("nome") + "!");

            } catch (JSONException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }



    }


}






