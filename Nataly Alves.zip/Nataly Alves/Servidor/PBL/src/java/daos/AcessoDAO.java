/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import beans.Usuario;
import conexao.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AcessoDAO {

    private Connection con = null;
    private PreparedStatement stmt = null;
    private ResultSet rs = null;
    


    public Usuario verificarLogin(String login, String senha) throws ClassNotFoundException, SQLException {
         try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM usuario WHERE login = ? AND senha = ?");
            stmt.setString(1, login);
            stmt.setString(2, senha);
            rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setLogin(login);
                usuario.setSenha(senha);
                usuario.setId(rs.getInt("id_usuario"));
                usuario.setNome(rs.getString("nome"));
                usuario.setSobrenome(rs.getString("sobrenome"));
                usuario.setTelefone(rs.getString("telefone"));
                usuario.setCpf(rs.getString("cpf"));
                usuario.setRg(rs.getString("rg"));
                return usuario;
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        return null;   
    }
    
     public boolean ValidarCadastro(String login, String cpf, String rg) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM usuario WHERE login = ? OR cpf = ? OR rg = ?");
            stmt.setString(1, login);
            stmt.setString(2, cpf);
            stmt.setString(3, rg);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return false;
            } else {
                return true;
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
    }
     
    public void Cadastrar(String login, String senha, String nome, String sobrenome, String telefone, String cpf, String rg, String sexo) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("INSERT INTO usuario (login, senha, nome, sobrenome, telefone, cpf, rg, sexo) VALUES ((?), (?), (?), (?), (?), (?), (?), (?))");
            stmt.setString(1, login);
            stmt.setString(2, senha);
            stmt.setString(3, nome);
            stmt.setString(4, sobrenome);
            stmt.setString(5, telefone);
            stmt.setString(6, cpf);
            stmt.setString(7, rg);
            stmt.setString(8, sexo);
            stmt.executeUpdate();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        
    }
    
        public void AlterarCadastro(String senha, String nome, String sobrenome, String telefone, String cpf) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("UPDATE usuario SET senha=(?), nome=(?),sobrenome=(?), telefone=(?) where cpf=(?);");
            stmt.setString(1, senha);
            stmt.setString(2, nome);
            stmt.setString(3, sobrenome);
            stmt.setString(4, telefone);
            stmt.setString(5, cpf);
            stmt.executeUpdate();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        
    }
    
         public Usuario BuscarUsuario(String cpf) throws ClassNotFoundException, SQLException {
         try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM usuario WHERE cpf = ?");
            stmt.setString(1, cpf);
            rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setLogin(rs.getString("login"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setId(rs.getInt("id_usuario"));
                usuario.setNome(rs.getString("nome"));
                usuario.setSobrenome(rs.getString("sobrenome"));
                usuario.setTelefone(rs.getString("telefone"));
                usuario.setCpf(rs.getString("cpf"));
                usuario.setRg(rs.getString("rg"));
                usuario.setSexo(rs.getString("sexo"));
                return usuario;
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        return null;   
    }
}
