/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daos;

import beans.Animal;
import beans.Usuario;
import conexao.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AnimalDAO {

    private Connection con = null;
    private PreparedStatement stmt = null;
    private ResultSet rs = null;
    
     
    public void CadastrarAnimal(String nome, String tipo, String raca, String porte, String sexo, String dono) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("INSERT INTO animal (nome, tipo, raca, porte, sexo, id_usuario) VALUES ((?), (?), (?), (?), (?), (?))");
            stmt.setString(1, nome);
            stmt.setString(2, tipo);
            stmt.setString(3, raca);
            stmt.setString(4, porte);
            stmt.setString(5, sexo);
            int donoint = Integer.parseInt(dono);
            stmt.setInt(6, donoint);
            stmt.executeUpdate();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        
    }
             
    public void AlterarCadastroAnimal(String id, String nome, String raca, String porte, String sexo) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("UPDATE animal SET nome=(?), raca=(?), porte=(?), sexo=(?) where id_animal =(?);");
            stmt.setString(1, nome);
            stmt.setString(2, raca);
            stmt.setString(3, porte);
            stmt.setString(4, sexo);
            int idInt = Integer.parseInt(id);
            stmt.setInt(5, idInt);
            stmt.executeUpdate();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        
    }
    
    public List<Animal> BuscarAnimal(int id, int dono) throws ClassNotFoundException, SQLException {
         try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM animal WHERE id_usuario = ? ORDER BY id_animal");
            stmt.setInt(1, dono);
            rs = stmt.executeQuery();
            List<Animal> animais = new ArrayList<>();
            while (rs.next()) {
                Animal animal = new Animal();
                animal.setId(rs.getInt("id_animal"));
                animal.setNome(rs.getString("nome"));
                animal.setTipo(rs.getString("tipo"));
                animal.setRaca(rs.getString("raca"));
                animal.setPorte(rs.getString("porte"));
                animal.setSexo(rs.getString("sexo"));
                animal.setDono(rs.getInt("id_usuario"));
                animal.setSituacao(rs.getString("situacao"));    
                animais.add(animal);
              
            }
              return animais;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }   
    }
    
    public Animal BuscarOAnimal(int id) throws ClassNotFoundException, SQLException {
         try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM animal WHERE id_animal = ?");
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                Animal animal = new Animal();
                animal.setId(rs.getInt("id_animal"));
                animal.setNome(rs.getString("nome"));
                animal.setTipo(rs.getString("tipo"));
                animal.setRaca(rs.getString("raca"));
                animal.setPorte(rs.getString("porte"));
                animal.setSexo(rs.getString("sexo"));
                animal.setDono(rs.getInt("id_usuario"));
                //animal.setSituacao(rs.getString("situacao"));    

               return animal;
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }  
         return null;
    }
    
    
    public void ExcluirAnimal(String id) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("DELETE FROM animal " +  "WHERE id_animal = (?);");
            int idInt = Integer.parseInt(id);
            stmt.setInt(1, idInt);
            stmt.executeUpdate();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        
    }
    
        public Usuario BuscarDono(int id) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM usuario " +  "WHERE id_usuario = (?);");
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario dono = new Usuario();
                dono.setNome(rs.getString("nome"));
                dono.setTelefone(rs.getString("telefone"));

               return dono;
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        return null;
    }
    
    
        public List<Animal> BuscarAnimaisParaAdocao(String tipo) throws ClassNotFoundException, SQLException {
         try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("SELECT * FROM animal WHERE tipo = (?) AND situacao = \'Não adotado\' ORDER BY id_animal");
            stmt.setString(1, tipo);
            rs = stmt.executeQuery();
            List<Animal> animais = new ArrayList<>();
            while (rs.next()) {
                Animal animal = new Animal();
                animal.setId(rs.getInt("id_animal"));
                animal.setNome(rs.getString("nome"));
                animal.setTipo(rs.getString("tipo"));
                animal.setRaca(rs.getString("raca"));
                animal.setPorte(rs.getString("porte"));
                animal.setSexo(rs.getString("sexo"));
                animal.setDono(rs.getInt("id_usuario"));
                animal.setSituacao(rs.getString("situacao"));    
                animais.add(animal);
              
            }
              return animais;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }   
    }
    
          public void AdotarAnimal(String id) throws ClassNotFoundException, SQLException {
        try {
            con = new ConnectionFactory().getConnection();
            stmt = con.prepareStatement("UPDATE animal SET situacao = \'Adotado\' where id_animal =(?);");
            int idInt = Integer.parseInt(id);
            stmt.setInt(1, idInt);
            stmt.executeUpdate();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar parâmetros: " + ex.getMessage());
            }
        }
        
    }
}