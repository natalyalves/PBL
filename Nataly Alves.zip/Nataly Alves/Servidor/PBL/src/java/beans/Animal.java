package beans;

import java.io.Serializable;


public class Animal implements Serializable {
    private int id;
    private String nome;
    private String tipo;
    private String raca;
    private String porte;
    private String sexo;
    private int dono;
    private String situacao;
   
    public Animal() {
    }

    public Animal(int id, String nome, String tipo,String raca, String porte, String sexo, int dono, String situacao) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.raca = raca;
        this.porte = porte;
        this.sexo = sexo;
        this.dono = dono;
        this.situacao = situacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }
    
    
    public String getPorte() {
        return porte;
    }

    public void setPorte(String porte) {
        this.porte = porte;
    }
    
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    public int getDono() {
        return dono;
    }

    public void setDono(int dono) {
        this.dono = dono;
    }

   public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

}
