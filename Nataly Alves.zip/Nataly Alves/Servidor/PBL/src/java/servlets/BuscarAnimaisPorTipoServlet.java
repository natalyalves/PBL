package servlets;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import beans.Animal;
import beans.Usuario;
import daos.AnimalDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;


@WebServlet(urlPatterns = {"/BuscarAnimaisPorTipoServlet"})
public class BuscarAnimaisPorTipoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HashMap<String, String> hm = new HashMap<>();
        String idSt = request.getParameter("id");
        String tipo = request.getParameter("tipo");
       
        int id = Integer.parseInt(idSt);
        
        AnimalDAO dao = new AnimalDAO();
        String mensagem = "";
        try{
            
            
            List<Animal> animais = new ArrayList<>();
             animais = dao.BuscarAnimaisParaAdocao(tipo);
             if(!animais.isEmpty()){
             Animal animal = new Animal();  
             animal = animais.get(id-1);
             int quantidade = animais.size();
             
             Usuario dono =   new Usuario();
             dono = dao.BuscarDono(animal.getDono());
               
               hm.put("dono",dono.getNome());
               hm.put("telefoneDono", dono.getTelefone());
               
                hm.put("id", String.valueOf(animal.getId()));
                hm.put("nome", String.valueOf(animal.getNome()));              
                hm.put("tipo", String.valueOf(animal.getTipo()));
                hm.put("raca", String.valueOf(animal.getRaca()));
                hm.put("porte", String.valueOf(animal.getPorte()));
               hm.put("sexo", String.valueOf(animal.getSexo()));
               hm.put("quantidade", String.valueOf(quantidade));
               hm.put("mensagem", "");
                //hm.put("situacao", String.valueOf(animal.getSituacao())); 
               
             }
             else
                 hm.put("mensagem", "Nenhum animal cadastrado!");
                 
        }catch (ClassNotFoundException | SQLException ex) {
            mensagem = "Erro de Conexão";
        }
        
        
        JSONObject json = JSONObject.fromObject(hm);
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
