package servlets;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import beans.Usuario;
import daos.AcessoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;


@WebServlet(urlPatterns = {"/BuscarUsuarioServlet"})
public class BuscarUsuarioServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HashMap<String, String> hm = new HashMap<>();
        String cpf = request.getParameter("cpf");
        AcessoDAO dao = new AcessoDAO();
        String mensagem = "";
        try{
            Usuario usuario = dao.BuscarUsuario(cpf);
           
                hm.put("id", String.valueOf(usuario.getId()));
                hm.put("login", String.valueOf(usuario.getLogin()));              
                hm.put("senha", String.valueOf(usuario.getSenha()));
                hm.put("nome", String.valueOf(usuario.getNome()));
                hm.put("sobrenome", String.valueOf(usuario.getSobrenome()));
                hm.put("telefone", String.valueOf(usuario.getTelefone()));
                hm.put("cpf", String.valueOf(usuario.getCpf()));
                hm.put("rg", String.valueOf(usuario.getRg()));
                hm.put("sexo", String.valueOf(usuario.getSexo()));
                
        }catch (ClassNotFoundException | SQLException ex) {
            mensagem = "Erro de Conexão";
        }
        
        JSONObject json = JSONObject.fromObject(hm);
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
